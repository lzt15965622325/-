# Cat-and-dog-classifier-Keras-Deep_learning-
This Repository distinguishes between the image of a cat and a dog using CNN.

This project aims to classify the input image as either a dog or a cat image. The image input which you give to the system will be analyzed and the predicted result will be given as output. Machine learning algorithm [Convolutional Neural Networks] is used to classify the image.
The model thus implemented can be extended to a mobile device or any website as per the developer’s need.


