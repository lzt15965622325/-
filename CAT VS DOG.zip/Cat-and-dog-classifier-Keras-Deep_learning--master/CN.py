from keras.preprocessing.image import ImageDataGenerator
train_datagen = ImageDataGenerator(rescale=1./255)
training_set = train_datagen.flow_from_directory("F:\\pycq\\py_tongxin\\CNN\\Cat-and-dog-classifier-Keras"
                                                 "-Deep_learning--master\\image_data\\training",target_size=(50,50),
                                                 batch_size=32,class_mode="binary")

from keras.models import Sequential
from keras.layers import Conv2D,MaxPool2D,Flatten,Dense

model = Sequential()
#卷积层 32个 大小3x3 输入大小 50X50 3通道 激活函数 relu
model.add(Conv2D(32,(3,3),input_shape=(50,50,3),activation="relu"))
#池化层
model.add(MaxPool2D(pool_size=(2,2) ) )
#卷积层
model.add(Conv2D(32,(3,3),activation="relu"))
#池化层
model.add(MaxPool2D(pool_size=(2,2) ) )
#flattening layer
model.add(Flatten())

#FC layer 全连接层
#128个神经元
model.add(Dense(units=128,activation="relu" ) )
model.add(Dense(units=1,activation="sigmoid"))#0/1二分类 用sigmoid

model.compile(optimizer="adam",loss="binary_crossentropy",metrics=['accuracy'])#最后是看训练效果的

model.summary()

model.fit_generator(training_set,epochs=98)
#模型 训练数据准确率
accuracy = model.evaluate_generator(training_set)
print(accuracy)

# 测试数据准确率
test_set = train_datagen.flow_from_directory("F:\\pycq\\py_tongxin\\CNN\\Cat-and-dog-classifier-Keras-Deep_learning--master\\image_data\\validation",target_size=(50,50),batch_size=32,class_mode="binary")
accuracy_test = model.evaluate_generator(test_set)
print(accuracy_test)

from keras.preprocessing.image import load_img,img_to_array

pic_dog = load_img("F:\\pycq\\py_tongxin\\CNN\\Cat-and-dog-classifier-Keras-Deep_learning--master\\image_data\\test\\234.jpg",target_size=(50,50))
pic_dog = img_to_array(pic_dog)
pic_dog = pic_dog/255 #维度转换
pic_dog = pic_dog.reshape(1,50,50,3)
result = model.predict_classes(pic_dog)

print(result)
if result==[[0]]:
    result='猫'
elif result==[[1]]:
    result='狗'
print(result)



